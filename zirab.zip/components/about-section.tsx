import type { NextPage } from "next";

const AboutSection: NextPage = () => {
  return (
    <div className="absolute top-[883px] left-[0px] bg-gainsboro w-[1516px] flex flex-row py-[55px] px-0 box-border items-center justify-center gap-[252px] text-left text-lgi text-black font-inter">
      <div className="flex flex-col items-start justify-start gap-[33px]">
        <div className="w-96 flex flex-row items-start justify-start gap-[59px]">
          <div className="rounded-smi box-border w-[180px] h-[150px] flex flex-col py-[21px] px-0 items-center justify-center gap-[10px] border-[2px] border-solid border-gray-400">
            <b className="relative">Role</b>
            <div className="relative text-[inherit] font-medium font-inherit inline-block w-[145px]">
              <ul className="m-0 pl-[25px]">
                <li className="mb-0">Designer</li>
                <li>{`Developer `}</li>
              </ul>
            </div>
          </div>
          <div className="rounded-smi box-border w-[180px] h-[150px] flex flex-col py-[9px] px-0 items-center justify-center gap-[10px] border-[2px] border-solid border-gray-400">
            <b className="relative">{`Audience `}</b>
            <div className="relative text-[inherit] font-medium font-inherit inline-block w-[169px]">
              <ul className="m-0 pl-[25px]">
                Anyone who’s looking for a way to be more creative.
              </ul>
            </div>
          </div>
        </div>
        <div className="flex flex-row items-start justify-start gap-[59px]">
          <div className="rounded-smi box-border w-[180px] h-[150px] flex flex-col py-[19px] px-0 items-center justify-center gap-[10px] border-[2px] border-solid border-gray-400">
            <b className="relative">Timeline</b>
            <div className="relative text-[inherit] font-medium font-inherit inline-block w-[145px]">
              <ul className="m-0 pl-[25px]">12 weeks to design and develop.</ul>
            </div>
          </div>
          <div className="rounded-smi box-border w-[180px] h-[150px] flex flex-col py-[19px] px-0 items-center justify-center gap-[10px] border-[2px] border-solid border-gray-400">
            <b className="relative">Tools</b>
            <div className="relative text-[inherit] font-medium font-inherit inline-block w-[169px]">
              <ul className="m-0 pl-[25px]">
                <li className="mb-0">Figma</li>
                <li>HTML/CSS/JavaScript</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div className="flex flex-col items-start justify-start gap-[27px] text-21xl text-dimgray-500">
        <div className="flex flex-row items-end justify-start gap-[14px]">
          <div className="relative font-black inline-block w-[222px] h-[85px] shrink-0">
            <p className="m-0">{`About `}</p>
            <p className="m-0">the Project</p>
          </div>
          <img
            className="relative w-[253px] h-[5px]"
            alt=""
            src="/rectangle-117.svg"
          />
        </div>
        <div className="relative text-lgi leading-[130%] text-black inline-block w-[522px] h-[129px] shrink-0">
          The desire to be more creative has become a universal aspiration.
          People from all walks of life, whether artists, professionals, or
          entrepreneurs, recognize the value of creativity in problem-solving,
          self-expression, and personal growth.
        </div>
      </div>
    </div>
  );
};

export default AboutSection;
