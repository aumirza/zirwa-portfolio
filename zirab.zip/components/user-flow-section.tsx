import type { NextPage } from "next";

const UserFlowSection: NextPage = () => {
  return (
    <div className="absolute top-[4476px] left-[0px] bg-gainsboro w-[1517px] h-[944px] flex flex-col py-[37px] px-[50px] box-border items-start justify-between text-left text-21xl text-dimgray-500 font-inter">
      <div className="flex flex-row items-end justify-start gap-[14px]">
        <div className="relative font-black inline-block w-[199px] h-[42px] shrink-0">
          User Flow
        </div>
        <div className="relative bg-goldenrod w-[253px] h-[3px]" />
      </div>
      <img
        className="self-stretch flex-1 relative max-w-full overflow-hidden max-h-full object-cover"
        alt=""
        src="/countdown-experience-final-1@2x.png"
      />
      <div className="relative text-base font-semibold text-gray-100 inline-block w-[734px] h-[23px] shrink-0">
        User flow of the website, to have an idea about how the user is going to
        interact on the website
      </div>
    </div>
  );
};

export default UserFlowSection;
