import type { NextPage } from "next";

const Footer: NextPage = () => {
  return (
    <div className="absolute bottom-[0px] left-[calc(50%_-_754px)] w-[1512px] h-[304px] text-left text-2xl text-white font-inter">
      <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%]">
        <div className="absolute h-[89.14%] w-full top-[10.86%] right-[0%] bottom-[0%] left-[0%]">
          <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-white shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)_inset]" />
          <div className="absolute h-[39.11%] w-[15.35%] top-[42.8%] right-[74.66%] bottom-[18.08%] left-[10%] text-center text-xl text-gray-600">
            <div className="absolute w-[209.5%] top-[-49.06%] left-[-7.97%] font-medium hidden">{`2023 Zirwa Tariq  `}</div>
            <img
              className="absolute h-[37.2%] w-[59.73%] top-[0%] right-[40.27%] bottom-[62.8%] left-[0%] max-w-full overflow-hidden max-h-full"
              alt=""
              src="/icons2.svg"
            />
            <div className="absolute w-full top-[54.72%] left-[0%] font-medium text-left inline-block">
              <p className="m-0">{`Let’s connect and help `}</p>
              <p className="m-0">each other grow</p>
            </div>
          </div>
          <div className="absolute h-[23.99%] w-[13.74%] top-[18.82%] right-[9.91%] bottom-[57.2%] left-[76.35%] rounded-smi bg-black overflow-hidden hidden flex-row py-[23px] px-[11px] box-border items-center justify-center">
            <b className="relative leading-[91.02%]">Download Resume</b>
          </div>
          <div className="absolute h-[23.99%] w-[13.61%] top-[55.35%] right-[10.04%] bottom-[20.66%] left-[76.35%] rounded-smi bg-black overflow-hidden hidden flex-row py-[23px] px-[41px] box-border items-center justify-center">
            <b className="relative leading-[91.02%]">Get in Touch</b>
          </div>
        </div>
        <img
          className="absolute h-[27.63%] w-[5.55%] top-[0%] right-[47.22%] bottom-[72.37%] left-[47.23%] max-w-full overflow-hidden max-h-full"
          alt=""
          src="/group-1801.svg"
        />
      </div>
      <img
        className="absolute h-[6.58%] w-[1.29%] top-[32.57%] right-[88.71%] bottom-[60.86%] left-[10%] max-w-full overflow-hidden max-h-full"
        alt=""
        src="/vector1.svg"
      />
      <div className="absolute h-[21.71%] w-[17.59%] top-[42.76%] right-[14.92%] bottom-[35.53%] left-[67.48%] text-5xl text-black">
        <div className="absolute top-[0%] left-[0%] [text-decoration:underline] leading-[100%] font-medium">
          Download PDF Resume
        </div>
        <div className="absolute top-[63.64%] left-[0%] leading-[100%] font-medium">
          Contact me
        </div>
      </div>
      <div className="absolute top-[31.91%] left-[11.42%] text-xl font-medium text-gray-600 text-center">{`2023 Zirwa Tariq  `}</div>
    </div>
  );
};

export default Footer;
