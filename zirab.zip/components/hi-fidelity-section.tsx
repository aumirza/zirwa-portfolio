import type { NextPage } from "next";

const HiFidelitySection: NextPage = () => {
  return (
    <div className="absolute top-[6864px] left-[0px] w-[1516px] h-[1365px] text-left text-base text-gray-100 font-inter">
      <div className="absolute top-[0px] left-[0px] w-[1516px] flex flex-col items-center justify-center gap-[120px]">
        <div className="flex flex-row items-start justify-start">
          <div className="flex flex-col items-center justify-start">
            <img
              className="relative w-[673px] h-[388px] object-cover"
              alt=""
              src="/final01-1@2x.png"
            />
            <div className="relative font-semibold inline-block w-[306px] h-[23px] shrink-0">{`Display of website on different screens `}</div>
          </div>
          <div className="flex flex-col items-start justify-start gap-[25px] ml-[-228px] text-21xl text-gray-300">
            <div className="flex flex-row items-end justify-start gap-[14px]">
              <div className="relative font-black inline-block w-[442px] h-[42px] shrink-0">{`Hi-fidelity Prototypes `}</div>
              <div className="relative bg-goldenrod w-[253px] h-[3px]" />
            </div>
            <div className="relative text-lgi leading-[130%] text-black inline-block w-[549px] h-[186px] shrink-0">
              Hi-fi provides a more polished and realistic representation of the
              final product or design concept and incorporates visual elements
              and detailed graphics, allowing stakeholders and users to better
              visualize and understand the intended look and feel of the design
              and enabling designers to simulate and test the user experience
              more accurately.
            </div>
          </div>
        </div>
        <img
          className="relative w-[1316px] h-[834px] object-cover"
          alt=""
          src="/animation-3@2x.png"
        />
      </div>
    </div>
  );
};

export default HiFidelitySection;
