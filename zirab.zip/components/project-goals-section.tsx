import type { NextPage } from "next";

const ProjectGoalsSection: NextPage = () => {
  return (
    <div className="absolute top-[1329px] left-[0px] w-[1516px] h-[1402px] text-left text-21xl text-dimgray-500 font-inter">
      <div className="absolute top-[505px] left-[0px] bg-dimgray-300 flex flex-col items-start justify-start">
        <img
          className="absolute my-0 mx-[!important] top-[0px] left-[calc(50%_-_518px)] w-[1038px] h-[891px] object-cover z-[0]"
          alt=""
          src="/paly-1@2x.png"
        />
      </div>
      <div className="absolute top-[0px] left-[105px] flex flex-col items-start justify-center">
        <div className="flex flex-col items-start justify-start gap-[29px]">
          <div className="flex flex-row items-end justify-start gap-[14px]">
            <div className="relative font-black inline-block w-[268px] h-[42px] shrink-0">
              Project Goals
            </div>
            <div className="relative bg-goldenrod w-[198px] h-[5px]" />
          </div>
          <div className="relative text-lgi leading-[130%] text-black inline-block w-[953px] h-[94px] shrink-0">
            The primary goal is to inspire individuals to embrace their creative
            potential and explore innovative thinking. By providing activities
            that aim to ignite a spark of creativity within each participant.
          </div>
        </div>
        <div className="w-[1284px] flex flex-row items-center justify-between text-11xl text-dimgray-400">
          <div className="w-[442px] h-[345px] flex flex-col items-start justify-start gap-[27px]">
            <b className="relative inline-block w-[319px] h-[65px] shrink-0">
              <p className="m-0">{`Play is `}</p>
              <p className="m-0">important</p>
            </b>
            <div className="relative text-[inherit] leading-[130%] font-inherit text-black inline-block w-[442px] h-[253px] shrink-0">
              <ul className="m-0 pl-[25px]">
                <li className="mb-0">
                  It creates a safe space where unconventional ideas can
                  flourish, enabling individuals to explore new perspectives and
                  generate innovative solutions.
                </li>
                <li className="mb-0">
                  Play allows for experimentation without the fear of failure or
                  judgment. It provides a platform to try out different
                  approaches, take risks, and test ideas.
                </li>
              </ul>
            </div>
          </div>
          <div className="flex flex-col items-start justify-start gap-[27px]">
            <b className="relative inline-block w-[431px] h-16 shrink-0">{`21 days countdown to become creative `}</b>
            <div className="relative text-lgi leading-[130%] text-black inline-block w-[442px] h-[237px] shrink-0">
              The idea that it takes 21 days to develop a habit is a popular
              concept. The significance of 21 days lies in establishing a
              consistent routine and allowing sufficient time for repetition and
              reinforcement of the desired behavior. By committing to a behavior
              for approximately three weeks, individuals can build momentum,
              increase their likelihood of success, and create a foundation for
              long-term habit formation.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectGoalsSection;
