import type { NextPage } from "next";

const HeroSection: NextPage = () => {
  return (
    <div className="absolute top-[calc(50%_-_7499px)] left-[calc(50%_-_758px)] bg-gainsboro w-[1512px] h-[800px] flex flex-row py-[25px] px-0 box-border items-center justify-center gap-[40px] text-left text-base text-gray-100 font-inter md:flex-col md:gap-[10px]">
      <div className="flex flex-col items-center justify-start">
        <img
          className="relative w-[673px] h-[774px] object-cover md:flex md:w-[350px] md:h-[450px]"
          alt=""
          src="/play1-1@2x.png"
        />
        <div className="relative font-semibold inline-block w-[501px] h-[19px] shrink-0">
          Two mobiles with two different interaction screens from website
        </div>
      </div>
      <div className="flex flex-col items-start justify-start gap-[5px] text-lgi text-dimgray-500">
        <div className="relative font-medium">{`Figma Prototype | Web Design | Web Development `}</div>
        <div className="relative inline-block w-[300px] h-[97px] shrink-0 text-21xl">
          <b>{`Play your way `}</b>
          <span className="text-25xl font-black">to Creativity</span>
        </div>
        <div className="relative bg-goldenrod w-[198px] h-[5px]" />
        <div className="relative leading-[130%] text-black inline-block w-[522px] h-[89px] shrink-0">{`There are many people who believe that creativity is either innate or not a talent that can be learned. But if there’s a way to be learn to be creative. `}</div>
        <div className="relative font-medium text-[inherit]">
          {`Figma Prototype : `}
          <a
            className="text-[inherit]"
            href={`https://www.figma.com/file/U6xKFaY8Isn9oe18h9UZIx/countdown-experience-Final?type=design&node-id=0%3A1&t=rqED9v91bIcnB5C7-1`}
            target="_blank"
          >
            <span className="[text-decoration:underline]">
              Play your way to creativity- functional prototype
            </span>
          </a>
        </div>
        <div className="relative font-medium text-[inherit]">
          {`Final Website : `}
          <a
            className="text-[inherit]"
            href="https://zirwatariq.github.io/project-2-repository-/"
            target="_blank"
          >
            <span className="[text-decoration:underline]">
              Play your way to creativity- functional website
            </span>
          </a>
        </div>
      </div>
    </div>
  );
};

export default HeroSection;
