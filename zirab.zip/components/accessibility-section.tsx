import type { NextPage } from "next";

const AccessibilitySection: NextPage = () => {
  return (
    <div className="absolute top-[8363px] left-[0px] w-[1516px] flex flex-row items-center justify-center gap-[44px] text-left text-21xl text-gray-300 font-inter">
      <div className="relative w-[644.5px] h-[719px]">
        <div className="absolute top-[0px] left-[0px] w-[644.5px] h-[719px] overflow-hidden">
          <img
            className="absolute top-[0px] left-[0px] w-[644.5px] h-[533.19px] object-cover"
            alt=""
            src="/screen-shot-20230516-at-733-1@2x.png"
          />
        </div>
        <img
          className="absolute top-[328.53px] left-[398.55px] w-[166.96px] h-[390.47px] object-cover"
          alt=""
          src="/screen-shot-20230516-at-745-1@2x.png"
        />
      </div>
      <div className="flex flex-col items-start justify-start gap-[27px]">
        <div className="flex flex-row items-end justify-start gap-[14px]">
          <div className="relative font-black inline-block w-[265px] h-[39px] shrink-0">{`Accessibility `}</div>
          <div className="relative bg-goldenrod w-[253px] h-[3px]" />
        </div>
        <div className="relative text-lgi leading-[130%] text-black inline-block w-[532px] h-[163px] shrink-0">
          Accessibility includes not only the outward depiction but also what is
          going on behind the scenes. Proper tags and structure are employed to
          deliver a more efficient experience to screen readers, and these
          concerns also lead to design modifications. To improve the user
          experience for screen readers.
        </div>
      </div>
    </div>
  );
};

export default AccessibilitySection;
