import type { NextPage } from "next";

const ConclusionSection: NextPage = () => {
  return (
    <div className="absolute top-[14440px] left-[0px] w-[1513px] h-[447px] flex flex-col py-0 px-[50px] box-border items-start justify-between text-left text-21xl text-gray-300 font-inter">
      <div className="flex flex-col items-start justify-start gap-[27px] z-[0]">
        <div className="flex flex-row items-end justify-start gap-[14px]">
          <div className="relative font-black inline-block w-[242px] h-[42px] shrink-0">{`Conclusion `}</div>
          <div className="relative bg-goldenrod w-[253px] h-[3px]" />
        </div>
        <div className="relative text-lgi leading-[130%] text-black inline-block w-[650px] h-[202px] shrink-0">
          By adopting a playful mindset, individuals are encouraged to break
          free from conventional thinking patterns and embrace curiosity,
          experimentation, and risk-taking. Play allows for the freedom to
          explore unconventional ideas, challenge assumptions, and generate
          novel solutions. It promotes a relaxed and open state of mind, which
          is conducive to generating fresh insights and making unexpected
          connections. Having a countdown experience enables the users to stay
          consistent and focused.
        </div>
      </div>
      <img
        className="absolute my-0 mx-[!important] top-[19px] right-[121px] w-[479px] h-[395px] object-cover z-[1]"
        alt=""
        src="/animation-2@2x.png"
      />
    </div>
  );
};

export default ConclusionSection;
