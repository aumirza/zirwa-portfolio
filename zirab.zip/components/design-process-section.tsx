import type { NextPage } from "next";

const DesignProcessSection: NextPage = () => {
  return (
    <div className="absolute top-[3726px] left-[0px] bg-gainsboro flex flex-col items-start justify-start text-left text-21xl text-dimgray-500 font-inter">
      <div className="my-0 mx-[!important] absolute top-[66px] left-[197px] bg-gainsboro flex flex-col items-start justify-start gap-[61px] z-[0]">
        <div className="w-[1124px] flex flex-col items-end justify-center gap-[25px]">
          <div className="flex flex-row items-end justify-start gap-[14px]">
            <div className="relative font-black inline-block w-[316px] h-[42px] shrink-0">
              Design Process
            </div>
            <div className="relative bg-goldenrod w-[247px] h-[3px]" />
          </div>
          <div className="self-stretch flex flex-row items-start justify-start text-lgi text-black">
            <div className="relative leading-[130%] inline-block w-[995px] h-[125px] shrink-0">
              Starting with empathizing and try to solve a problem user is
              facing by proper defining it and ideating the best possible
              solutions to create the prototypes, Test the prototypes for user
              feedback so they can be improved based on the feedback of the
              users. Once the prototypes are ready, develop the website by
              working on semantic structure and accessibility, validate the
              codes properly in terms of structure and accessibility, and test
              again for final results.
            </div>
          </div>
        </div>
        <div className="w-[1118px] h-[377px] flex flex-col items-center justify-start text-5xl text-gray-500">
          <div className="flex flex-col items-center justify-start gap-[81px]">
            <div className="w-[1122.5px] h-[150.21px] flex flex-row items-center justify-start gap-[135px]">
              <div className="w-[133px] flex flex-col items-center justify-start gap-[10px] text-center">
                <img
                  className="relative w-[181px] h-[114px] overflow-hidden shrink-0"
                  alt=""
                  src="/layer-11.svg"
                />
                <div className="relative font-semibold"> Empathize</div>
              </div>
              <div className="w-[116px] h-[139px] flex flex-col items-center justify-start gap-[8px] text-center">
                <img
                  className="relative w-[125px] h-[113px] overflow-hidden shrink-0"
                  alt=""
                  src="/layer-12.svg"
                />
                <div className="relative font-semibold">Define</div>
              </div>
              <div className="w-[76px] h-[137px] flex flex-col items-center justify-start gap-[8px]">
                <img
                  className="relative w-[86px] h-[112.17px]"
                  alt=""
                  src="/group-154.svg"
                />
                <div className="relative font-semibold">Ideate</div>
              </div>
              <div className="w-[133px] h-[143px] flex flex-col items-center justify-start gap-[10px]">
                <img
                  className="relative w-[141.99px] h-[114px]"
                  alt=""
                  src="/group-155.svg"
                />
                <div className="relative font-semibold">Prototype</div>
              </div>
              <div className="w-[77px] h-[139px] flex flex-col items-center justify-start gap-[11px]">
                <img
                  className="relative w-[83.47px] h-[111.48px]"
                  alt=""
                  src="/group-156.svg"
                />
                <div className="relative font-semibold">User Testing</div>
              </div>
            </div>
            <div className="w-[707.96px] h-[145.3px] flex flex-row items-center justify-start gap-[135px]">
              <div className="w-[100px] h-[141px] flex flex-col items-center justify-start gap-[9px]">
                <img
                  className="relative w-[108.18px] h-[114.23px]"
                  alt=""
                  src="/group-150.svg"
                />
                <div className="relative font-semibold">{`Develop `}</div>
              </div>
              <div className="w-[172px] h-[135px] flex flex-col items-center justify-start gap-[8px]">
                <img
                  className="relative w-[119px] h-[113px]"
                  alt=""
                  src="/group-157.svg"
                />
                <div className="relative font-semibold">Code Validation</div>
              </div>
              <div className="w-[136px] flex flex-col items-center justify-start gap-[12px]">
                <img
                  className="relative w-[114px] h-[107px]"
                  alt=""
                  src="/group-153.svg"
                />
                <div className="relative font-semibold">User Testing</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DesignProcessSection;
