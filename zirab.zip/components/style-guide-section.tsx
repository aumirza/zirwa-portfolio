import type { NextPage } from "next";

const StyleGuideSection: NextPage = () => {
  return (
    <div className="absolute top-[9082px] left-[0px] w-[1516px] h-[1083px] flex flex-col py-[21px] px-0 box-border items-center justify-center text-left text-lgi text-black font-inter">
      <div className="flex flex-col items-center justify-start gap-[58px]">
        <div className="flex flex-row items-start justify-start gap-[265px]">
          <div className="relative leading-[130%] inline-block w-[509px] h-[137px] shrink-0">
            A style guide is a set of guidelines and standards that define the
            visual and functional elements of a digital design. It serves as a
            reference for designers, developers, and stakeholders, helps
            maintain brand consistency, and serves as a communication tool among
            the designers and developers.
          </div>
          <div className="flex flex-row items-end justify-start gap-[14px] text-21xl text-gray-300">
            <div className="relative font-black inline-block w-[237px] h-[42px] shrink-0">
              Style Guide
            </div>
            <div className="relative bg-goldenrod w-[253px] h-[3px]" />
          </div>
        </div>
        <div className="flex flex-row items-start justify-start">
          <img
            className="relative w-[806px] h-[776px] object-cover"
            alt=""
            src="/screen-shot-20230516-at-758-1@2x.png"
          />
          <img
            className="relative w-[716px] h-[776px] object-cover"
            alt=""
            src="/screen-shot-20230516-at-758-2@2x.png"
          />
        </div>
      </div>
    </div>
  );
};

export default StyleGuideSection;
