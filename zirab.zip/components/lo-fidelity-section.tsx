import type { NextPage } from "next";

const LoFidelitySection: NextPage = () => {
  return (
    <div className="absolute top-[5467px] left-[1px] w-[1516px] flex flex-col items-center justify-start gap-[38px] text-left text-lgi text-black font-inter">
      <div className="flex flex-row items-start justify-start gap-[84px]">
        <div className="relative leading-[130%] inline-block w-[483px] h-[124px] shrink-0">{`Lo-fi prototypes can be created rapidly and involve simple materials like paper, sketches, or digital wireframes, which allows designers to iterate and test ideas without investing significant time or resources upfront. `}</div>
        <div className="flex flex-row items-end justify-start gap-[14px] text-21xl text-gray-300">
          <div className="relative font-black inline-block w-[443px] h-[42px] shrink-0">{`Lo-fidelity Prototypes `}</div>
          <div className="relative bg-goldenrod w-[253px] h-[3px]" />
        </div>
      </div>
      <div className="flex flex-row items-center justify-start gap-[28px]">
        <img
          className="relative w-[273.23px] h-[439.62px] object-cover"
          alt=""
          src="/img-4186@2x.png"
        />
        <img
          className="relative w-[315.18px] h-[441.58px] object-cover"
          alt=""
          src="/img-4187@2x.png"
        />
        <img
          className="relative w-[287.4px] h-[443.14px] object-cover"
          alt=""
          src="/img-4185@2x.png"
        />
        <img
          className="relative w-[280.75px] h-[442.36px] object-cover"
          alt=""
          src="/img-4184@2x.png"
        />
        <img
          className="relative w-[279.45px] h-[442.36px] object-cover"
          alt=""
          src="/img-4183@2x.png"
        />
      </div>
      <div className="flex flex-col items-center justify-start gap-[6px] text-base text-gray-100">
        <div className="flex flex-col p-2.5 items-start justify-start">
          <img
            className="relative w-[1511px] h-[563px] object-cover"
            alt=""
            src="/screen-shot-20230516-at-641-1@2x.png"
          />
        </div>
        <div className="relative font-semibold inline-block w-[510px] h-[23px] shrink-0">
          Exploration of different interactions on paper and digital interface
        </div>
      </div>
    </div>
  );
};

export default LoFidelitySection;
