import type { NextPage } from "next";
import ProjectGoalsSection from "../components/project-goals-section";
import Footer from "../components/footer";
import ConclusionSection from "../components/conclusion-section";
import HeroSection from "../components/hero-section";
import AboutSection from "../components/about-section";
import DesignProcessSection from "../components/design-process-section";
import UserFlowSection from "../components/user-flow-section";
import LoFidelitySection from "../components/lo-fidelity-section";
import HiFidelitySection from "../components/hi-fidelity-section";
import AccessibilitySection from "../components/accessibility-section";
import StyleGuideSection from "../components/style-guide-section";
import VisualDesignSection from "../components/visual-design-section";

const MacBookPro143: NextPage = () => {
  return (
    <div className="relative bg-white w-full h-[15158px] overflow-hidden text-left text-21xl text-gray-400 font-inter">
      <ProjectGoalsSection />
      <div className="absolute top-[0px] left-[calc(50%_-_758px)] flex flex-col items-start justify-start text-7xl">
        <div className="bg-white shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25),_0px_4px_4px_rgba(0,_0,_0,_0.25)] flex flex-row flex-wrap items-center justify-center relative gap-[10px]">
          <img
            className="absolute my-0 mx-[!important] top-[20.94px] left-[131px] w-[167.33px] h-11 overflow-hidden shrink-0 z-[0]"
            alt=""
            src="/layer-1.svg"
          />
          <div className="my-0 mx-[!important] absolute top-[25px] right-[91px] flex flex-row items-start justify-start gap-[60px] z-[1]">
            <div className="relative w-[75px] h-[31px]">
              <b className="absolute top-[0%] left-[0%]">{`Home `}</b>
            </div>
            <div className="w-[88px] flex flex-row items-center justify-end">
              <div className="flex-1 relative h-[31px]">
                <b className="absolute top-[0%] left-[0%]">{`Work `}</b>
              </div>
              <div className="relative w-[13px] h-[31px] text-black">
                <b className="absolute top-[100%] left-[100%] [transform:_rotate(-180deg)] [transform-origin:0_0]">
                  ^
                </b>
              </div>
            </div>
            <div className="relative w-[88px] h-[31px]">
              <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%]">
                <b className="absolute top-[0%] left-[0%]">About</b>
              </div>
            </div>
            <div className="relative w-[105px] h-[31px]">
              <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%]">
                <b className="absolute top-[0%] left-[0%]">Contact</b>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
      <ConclusionSection />
      <HeroSection />
      <AboutSection />
      <div className="absolute top-[2731px] left-[-2px] w-[1518px] h-[1000px] flex flex-col items-center justify-center gap-[51px] text-dimgray-500">
        <div className="my-0 mx-[!important] absolute top-[81.59px] left-[116px] flex flex-row items-center justify-center gap-[14px] z-[0]">
          <div className="relative font-black inline-block w-[333px] h-[41.79px] shrink-0">
            Project Timeline
          </div>
          <div className="relative bg-goldenrod w-[253px] h-[2.98px]" />
        </div>
        <div className="relative w-[1518px] h-[800px] z-[1] text-lgi text-black">
          <div className="absolute top-[131.4px] left-[0px] w-[1604px] h-[518.4px]">
            <div className="absolute top-[0px] left-[237px] w-[859px] h-[262.68px] overflow-hidden">
              <div className="absolute top-[0px] left-[859px] bg-dimgray-100 w-[262.68px] h-[13px] [transform:_rotate(90deg)] [transform-origin:0_0]" />
              <div className="absolute top-[0px] left-[0px] w-[420px] h-[262.68px] overflow-hidden">
                <div className="absolute top-[0px] left-[13px] bg-dimgray-100 w-[262.68px] h-[13px] [transform:_rotate(90deg)] [transform-origin:0_0]" />
                <div className="absolute top-[0px] left-[420px] bg-dimgray-100 w-[262.68px] h-[13px] [transform:_rotate(90deg)] [transform-origin:0_0]" />
              </div>
            </div>
            <div className="absolute top-[246.76px] left-[0px] w-[1604px] h-[271.64px] overflow-hidden">
              <div className="absolute top-[0px] left-[0px] bg-dimgray-100 w-[1604px] h-[20.9px]" />
              <div className="absolute top-[8.96px] left-[407px] bg-dimgray-100 w-[262.68px] h-[13px] [transform:_rotate(90deg)] [transform-origin:0_0]" />
              <div className="absolute top-[8.96px] left-[828px] bg-dimgray-100 w-[262.68px] h-[13px] [transform:_rotate(90deg)] [transform-origin:0_0]" />
              <div className="absolute top-[8.96px] left-[1255px] bg-dimgray-100 w-[262.68px] h-[13px] [transform:_rotate(90deg)] [transform-origin:0_0]" />
            </div>
          </div>
          <div className="absolute top-[0.06px] left-[calc(50%_-_658.5px)] w-[285px] h-[300px] flex flex-col py-[30px] px-[50px] box-border items-center justify-center gap-[7px] bg-[url(/frame-294@3x.png)] bg-cover bg-no-repeat bg-[top]">
            <div className="relative font-medium inline-block w-[77px] h-[22.89px] shrink-0">
              Week 01
            </div>
            <b className="relative text-xl text-dimgray-800">
              Identify problem
            </b>
            <div className="relative text-[inherit] font-inherit inline-block w-[206px] h-[111.44px] shrink-0">
              <ul className="m-0 pl-[25px]">
                <li className="mb-0">Identify the problem.</li>
                <li>{`Come up with best possible solution. `}</li>
              </ul>
            </div>
          </div>
          <div className="absolute top-[480.65px] left-[calc(50%_-_474px)] w-[286px] h-[300px] flex flex-col py-[30px] px-[50px] box-border items-center justify-center gap-[7px] bg-[url(/frame-297@3x.png)] bg-cover bg-no-repeat bg-[top]">
            <div className="relative font-medium inline-block w-[115px] h-[22.89px] shrink-0">
              Week 02, 03
            </div>
            <b className="relative text-xl inline-block text-dimgray-800 w-[133px]">
              Strategies to benefit users
            </b>
            <div className="relative text-[inherit] font-inherit inline-block w-[206px] h-[111.44px] shrink-0">
              <ul className="m-0 pl-[25px]">{`Planning how to implement the best solutions for better user experience. `}</ul>
            </div>
          </div>
          <div className="absolute top-[480.65px] left-[calc(50%_-_71.5px)] w-[300px] h-[300px] flex flex-col py-[30px] px-[50px] box-border items-center justify-center gap-[7px] bg-[url(/frame-298@3x.png)] bg-cover bg-no-repeat bg-[top]">
            <div className="relative font-medium inline-block w-[113px] h-[22.89px] shrink-0">
              Week 06, 07
            </div>
            <b className="self-stretch relative text-xl inline-block text-dimgray-800 h-[47.76px] shrink-0">
              Finalize and test prototypes
            </b>
            <div className="relative text-[inherit] font-inherit inline-block w-[226px] h-[111.44px] shrink-0">
              <ul className="m-0 pl-[25px]">{`Finalize the prototypes and test for the user experience and functionality. `}</ul>
            </div>
          </div>
          <div className="absolute top-[480.65px] left-[calc(50%_+_361.5px)] w-[300px] h-[300px] flex flex-col py-[30px] px-[50px] box-border items-center justify-end gap-[7px] bg-[url(/frame-298@3x.png)] bg-cover bg-no-repeat bg-[top]">
            <div className="relative font-medium inline-block w-[104px] h-[22.89px] shrink-0">
              Week 11, 12
            </div>
            <b className="relative text-xl inline-block text-dimgray-800 w-[199px] h-[47.76px] shrink-0">
              Develop and validate codes.
            </b>
            <div className="relative text-[inherit] font-inherit inline-block w-[206px] h-[111.44px] shrink-0">
              <ul className="m-0 pl-[25px]">
                <li className="mb-0">{`Develop the website. `}</li>
                <li>Validate the codes.</li>
              </ul>
            </div>
          </div>
          <div className="absolute top-[0.06px] left-[calc(50%_+_185.5px)] w-[285px] h-[300px] flex flex-col pt-[50px] px-[50px] pb-[30px] box-border items-center justify-center gap-[7px] bg-[url(/frame-294@3x.png)] bg-cover bg-no-repeat bg-[top]">
            <div className="relative font-medium inline-block w-[145px] h-[22.89px] shrink-0">
              Week 08, 09, 10
            </div>
            <b className="relative text-xl text-dimgray-800">
              <p className="m-0">User feedback,</p>
              <p className="m-0">semantic code</p>
            </b>
            <div className="relative text-[inherit] font-inherit inline-block w-[206px] h-[111.44px] shrink-0">
              <ul className="m-0 pl-[25px]">
                <li className="mb-0">Ask for feedback.</li>
                <li>Build a semantic structure to develop.</li>
              </ul>
            </div>
          </div>
          <div className="absolute top-[0.06px] left-[calc(50%_-_246.5px)] w-[300px] h-[300px] flex flex-col py-1 px-[50px] box-border items-center justify-center gap-[7px] bg-[url(/frame-295@3x.png)] bg-cover bg-no-repeat bg-[top]">
            <div className="relative font-medium inline-block w-[114px] h-[22.89px] shrink-0">
              Week 04, 05
            </div>
            <b className="relative text-xl text-dimgray-800">
              Work on prototypes
            </b>
            <div className="relative text-[inherit] font-inherit inline-block w-[206px] h-[111.44px] shrink-0">
              <ul className="m-0 pl-[25px]">
                <li className="mb-0">Work on lo-fi prototypes.</li>
                <li>{`Work on Hi-fi prototypes. `}</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <DesignProcessSection />
      <UserFlowSection />
      <LoFidelitySection />
      <HiFidelitySection />
      <AccessibilitySection />
      <StyleGuideSection />
      <VisualDesignSection />
      <div className="absolute top-[11340px] left-[calc(50%_-_757px)] bg-dimgray-700 w-[1518px] h-[3100px] text-white">
        <div className="absolute top-[39.91px] left-[calc(50%_-_645px)] flex flex-row items-end justify-start gap-[14px]">
          <div className="relative font-black inline-block w-[353px] h-[41.91px] shrink-0">{`Product Features `}</div>
          <div className="relative bg-goldenrod w-[253px] h-[2.99px]" />
        </div>
        <div className="absolute top-[151px] left-[-1px] w-[1513px] overflow-hidden flex flex-col items-start justify-center text-lgi">
          <div className="w-[1514px] flex flex-row py-0 px-[118px] box-border items-center justify-center gap-[260px] text-[inherit] font-inherit">
            <div className="relative leading-[130%] inline-block w-[495px] h-[148.66px] shrink-0">
              <p className="m-0">
                Home page provides the whole walk through of the website, Easy
                sign up helps the users to registered and also highlights how
                this challenge works.
              </p>
              <ul className="m-0 pl-[25px]">
                <li className="mb-0">Walkthrough of the website.</li>
                <li className="mb-0">Importance of play in creative process</li>
                <li>Easy sign up</li>
              </ul>
            </div>
            <div className="relative w-[427px] h-[704.13px]">
              <div className="absolute top-[0px] left-[0px] w-[263.61px] h-[704.13px] overflow-hidden">
                <img
                  className="absolute top-[177.26px] left-[0px] w-[263.61px] h-[526.87px] object-cover"
                  alt=""
                  src="/homepage-2@2x.png"
                />
              </div>
              <div className="absolute top-[0px] left-[197px] w-[230px] h-[704.13px] overflow-hidden">
                <div className="absolute top-[0px] left-[0px] rounded-[38px] flex flex-row items-center justify-center bg-[url(/frame-196@3x.png)] bg-cover bg-no-repeat bg-[top]">
                  <img
                    className="absolute my-0 mx-[!important] top-[5.29px] left-[0px] w-[230px] h-[526.87px] object-cover z-[0]"
                    alt=""
                    src="/image-41@2x.png"
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="w-[1514px] flex flex-row py-0 px-[89px] box-border items-center justify-center gap-[45px] mt-[-50px]">
            <div className="relative w-[718.27px] h-[827.21px]">
              <div className="absolute top-[0px] left-[0px] w-[537.2px] h-[827.87px] overflow-hidden">
                <div className="absolute top-[0px] left-[0px] w-[537.2px] h-[677.18px]">
                  <img
                    className="absolute top-[0px] left-[0px] w-[537.2px] h-[677.18px] object-cover"
                    alt=""
                    src="/image-5@2x.png"
                  />
                  <img
                    className="absolute top-[28.73px] left-[41.13px] rounded-2xl w-[456.58px] h-[607.41px] object-cover"
                    alt=""
                    src="/calendar-1@2x.png"
                  />
                </div>
              </div>
              <div className="absolute top-[272.87px] left-[398px] w-[321px] h-[555px] overflow-hidden">
                <div className="absolute top-[0px] left-[0px] w-[321px] h-[555px]">
                  <img
                    className="absolute top-[0.03px] left-[0.13px] w-[320.14px] h-[554.31px] object-cover"
                    alt=""
                    src="/image-42@2x.png"
                  />
                  <img
                    className="absolute top-[24.27px] left-[40.03px] rounded-10xl w-[240.78px] h-[507.87px] object-cover"
                    alt=""
                    src="/screen-shot-20230516-at-919-1@2x.png"
                  />
                </div>
              </div>
            </div>
            <div className="relative leading-[130%] inline-block w-[541px] h-[76.83px] shrink-0">
              A calendar page helps the user to keep track of activities and an
              easy access to all the activity pages from one page.
            </div>
          </div>
          <div className="w-[1514px] flex flex-row py-0 px-[114px] box-border items-center justify-center gap-[173px] mt-[-50px]">
            <div className="relative leading-[130%] inline-block w-[512px] h-[166.62px] shrink-0">{`A music feature is also incorporated to the website for the users who prefer to play music while working. Images are also provided to give the visual aid and Hint feature is also available for help on each activity page. `}</div>
            <div className="relative w-[583.16px] h-[858.06px]">
              <img
                className="absolute top-[0px] left-[211.95px] w-[340.96px] h-[439.88px] object-cover"
                alt=""
                src="/screen-shot-20230516-at-903-1@2x.png"
              />
              <img
                className="absolute top-[163.26px] left-[2.66px] w-[348.58px] h-[444.62px] object-cover"
                alt=""
                src="/screen-shot-20230516-at-904-1@2x.png"
              />
              <img
                className="absolute top-[467px] left-[250px] w-[337.16px] h-[209.23px] object-cover"
                alt=""
                src="/screen-shot-20230516-at-907-1@2x.png"
              />
              <img
                className="absolute top-[616.97px] left-[-4px] w-[314.33px] h-[249.09px] object-cover"
                alt=""
                src="/screen-shot-20230516-at-923-1@2x.png"
              />
            </div>
          </div>
          <div className="w-[1513px] flex flex-row items-center justify-center gap-[168px] mt-[-50px]">
            <div className="relative w-[646px] h-[605.63px]">
              <div className="absolute top-[-0.44px] left-[111px] w-[475px] h-[605.63px] overflow-hidden">
                <img
                  className="absolute top-[0px] left-[0px] w-[475px] h-[441px] object-cover"
                  alt=""
                  src="/screen-shot-20230518-at-1150-1@2x.png"
                />
              </div>
              <img
                className="absolute top-[149.22px] left-[539px] w-[218px] h-[455.97px] object-cover"
                alt=""
                src="/screen-shot-20230518-at-1145-1@2x.png"
              />
            </div>
            <div className="relative leading-[130%] inline-block w-[533px] h-[73.83px] shrink-0">
              A daily email reminder for the users to provide them a sneak peak
              about the activity and keep them engaged to the countdown
              experience.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MacBookPro143;
